/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/**
 * Model for the Appointment class
 * @author William Gunther
 */
public class Appointment 
{
  
    private int apptId;
    private String title;
    private String description;
    private String location;
    private String type;
    private LocalDate sDate;
    private LocalDateTime sTime;
    private LocalDate eDate;
    private LocalDateTime eTime;
    private int customerId;
    private int userId;
    private int contactId;
    

    /**
     * Appointment class
     * @param apptId Int Appointment Id
     * @param title String Appointment Title
     * @param description String Appointment Description
     * @param location String Appointment Location
     * @param type String Appointment Type
     * @param sDate LocalDate Appointment Start Date
     * @param sTime LocalDateTime Appointment Start Time
     * @param eDate LocalDate Appointment End Date
     * @param eTime LocalDateTime Appointment End Time
     * @param customerId Int Customer Id of the associated appointment
     * @param userId Int User Id of the associated appointment
     * @param contactId Int Contact Id of the associated appointment
     */
            public Appointment
                    (
                    int apptId,
                    String title,
                    String description,
                    String location,
                    String type,
                    LocalDate sDate,
                    LocalDateTime sTime,
                    LocalDate eDate,
                    LocalDateTime eTime,
                    int customerId,
                    int userId,
                    int contactId
                    
                     ) {
                        this.apptId = apptId;
                        this.title = title;
                        this.description = description;
                        this.location = location;
                        this.type = type;
                        this.sDate = sDate;
                        this.sTime = sTime;
                        this.eDate = eDate;
                        this.eTime = eTime;
                        this.customerId = customerId;
                        this.userId = userId;
                        this.contactId = contactId;
        
                         }

    /** Gets Appt ID
     * @return apptId Int value of Appointment ID
     */
    public int getApptId() 
    {
        return apptId;
    }

    /** Sets Appt ID
     * @param apptId Int value of Appointment ID
     */
    public void setApptId(int apptId) 
    {
        this.apptId = apptId;
    }
    
    

    /** Gets Appt Title
     * @return title String value of Appointment Name 
     */
    public String getTitle() 
    {
        return title;
    }

    /** Sets Appt Title
     * @param title String value of Appointment Title*/
    public void setTitle(String title) 
    {
        this.title = title;
    }

    /** Gets Appt Description
     * @return description String value of Appointment Description 
     */
    public String getDescription() 
    {
        return description;
    }

    /** Sets Appt Description
     * @param description String value of Appointment Description
     */
    public void setDescription(String description) 
    {
        this.description = description;
    }

    /** Gets Appt Location
     * @return location String value of Appointment Location 
     */
    public String getLocation() 
    {
        return location;
    }

    /** Sets Appt Location
     * @param location String value of Appointment Location
     */
    public void setLocation(String location) 
    {
        this.location = location;
    }

    /** Gets Appt Type
     * @return type String value of Appointment Type 
     */
    public String getType() 
    {
        return type;
    }

    /** Sets Appt Type
     * @param type String value of Appointment Type
     */
    public void setType(String type) 
    {
        this.type = type;
    }

    /** Gets Start Date
     * @return sDate LocalDate value of Appointment Start Date 
     */
    public LocalDate getSDate() 
    {
        return sDate;
    }

    /** Sets Appt Start Date
     * @param sDate LocalDate value of Appointment Start Date
     */
    public void setSDate(LocalDate sDate) 
    {
        this.sDate = sDate;
    }

    /** Gets Appt Start Time
     * @return sTime LocalDateTime value of Appointment Start Time 
     */
    public LocalDateTime getSTime() 
    {
        return sTime;
    }

    /** Sets Appt Start Time
     * @param sTime LocalDateTime value of Appointment Start Time
     */
    public void setSTime(LocalDateTime sTime) 
    {
        this.sTime = sTime;
    }

    /** Gets Appt End Date
     * @return eDate LocalDate value of Appointment End Date 
     */
    public LocalDate getEDate() 
    {
        return eDate;
    }

    /** Sets Appt End Date
     * @param eDate LocalDate value of Appointment End Date
     */
    public void setEDate(LocalDate eDate) 
    {
        this.eDate = eDate;
    }

    /** Gets Appt End Time
     * @return eTime LocalDateTime value of Appointment End Time 
     */
    public LocalDateTime getETime() 
    {
        return eTime;
    }

    /** Sets Appt End Time
     * @param eTime LocalDateTime value of Appointment End Time
     */
    public void setETime(LocalDateTime eTime) 
    {
        this.eTime = eTime;
    }

    /** Gets Customer ID
     * @return customerId Integer value of Customer ID
     */
    public int getCustomerId() 
    {
        return customerId;
    }

    /** Sets Customer ID
     * @param customerId Integer value of Customer ID
     */
    public void setCustomerId(int customerId) 
    {
        this.customerId = customerId;
    }

    /** Gets User ID
     * @return userId Integer value of User ID
     */
    public int getUserId() 
    {
        return userId;
    }

    /** Sets User ID
     * @param userId Integer value of User ID
     */
    public void setUserId(int userId) 
    {
        this.userId = userId;
    }

    /** Gets Contact ID
     * @return contactId Integer value of Contact ID
     */
    public int getContactId() 
    {
        return contactId;
    }

    /** Sets Contact ID
     * @param contactId Integer value of Contact ID
     */
    public void setContactId(int contactId) 
    {
        this.contactId = contactId;
    }

    
}