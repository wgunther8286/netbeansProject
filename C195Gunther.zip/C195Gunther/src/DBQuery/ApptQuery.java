/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBQuery;

import Model.Appointment;
import java.time.LocalDateTime;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import Helper.*;
import Model.Contact;
import java.sql.*;

/**
 * Class for the appointments query
 * @author William Gunther
 */
public class ApptQuery 
{
    
    /** Gets all Appointments
     * @return ObservableList Returns list of Appointments
     * @throws SQLException Catches SQLException and prints stacktrace.
     */
    public static ObservableList<Appointment> getAppts() throws SQLException
    {
       
        ObservableList<Appointment> allAppts = FXCollections.observableArrayList();
        try {
            String sql = "SELECT * FROM appointments";
            PreparedStatement ps = JDBC.getConn().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) 
            {
                Appointment a = new Appointment(
                        rs.getInt("Appointment_ID"),
                        rs.getString("Title"),
                        rs.getString("Description"),
                        rs.getString("Location"),
                        rs.getString("Type"),
                        rs.getDate("Start").toLocalDate(),
                        rs.getTimestamp("Start").toLocalDateTime(),
                        rs.getDate("End").toLocalDate(),
                        rs.getTimestamp("End").toLocalDateTime(),
                        rs.getInt("Customer_ID"),
                        rs.getInt("User_ID"),
                        rs.getInt("Contact_ID"));
                       
                allAppts.add(a);
            }
            return allAppts;
        }catch(SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**Gets a list of appts in the next 7 days
     * @return ObservableList Returns list of Appointments
     * @throws SQLException Catches SQLException, prints stacktrace, and error message.
     */
    public static ObservableList<Appointment> getApptsWk() throws SQLException 
    {
        ObservableList<Appointment> appts = FXCollections.observableArrayList();

        LocalDateTime today = LocalDateTime.now();
        LocalDateTime nextWk = today.minusDays(7);

        String qStatement = "SELECT * FROM appointments AS a INNER JOIN contacts AS c ON a.Contact_ID=c.Contact_ID WHERE Start < ? AND Start > ?;";

       PreparedStatement ps = JDBC.getConn().prepareStatement(qStatement);

            

        ps.setDate(1, java.sql.Date.valueOf(today.toLocalDate()));
        ps.setDate(2, java.sql.Date.valueOf(nextWk.toLocalDate()));

        try {
            ps.execute();
            ResultSet rs = ps.getResultSet();

            while (rs.next()) 
            {
                Appointment newAppt = new Appointment(
                        rs.getInt("Appointment_ID"),
                        rs.getString("Title"),
                        rs.getString("Description"),
                        rs.getString("Location"),
                        rs.getString("Type"),
                        rs.getDate("Start").toLocalDate(),
                        rs.getTimestamp("Start").toLocalDateTime(),
                        rs.getDate("End").toLocalDate(),
                        rs.getTimestamp("End").toLocalDateTime(),
                        rs.getInt("Customer_ID"),
                        rs.getInt("User_ID"),
                        rs.getInt("Contact_ID")
                        
                                );

                appts.add(newAppt);
            }
            return appts;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        }
    }
    /**
     * Gets a list of Appointments for the next 30 days
     * @return ObservableList of appointments
     * @throws SQLException Catches SQLException, prints stacktrace, and error message.
     */
    public static ObservableList<Appointment> getApptsMth() throws SQLException 
    {
        ObservableList<Appointment> appts = FXCollections.observableArrayList();

        LocalDateTime today = LocalDateTime.now();
        LocalDateTime nextMnth = today.minusDays(30);

        String qStatement = "SELECT * FROM appointments AS a INNER JOIN contacts AS c ON a.Contact_ID = c.Contact_ID WHERE Start < ? AND Start > ?;";

        PreparedStatement ps = JDBC.getConn().prepareStatement(qStatement);
   
        ps.setDate(1, java.sql.Date.valueOf(today.toLocalDate()));
        ps.setDate(2, java.sql.Date.valueOf(nextMnth.toLocalDate()));

        try {
            ps.execute();
            ResultSet rs = ps.getResultSet();

            while (rs.next()) 
            {
                Appointment newAppt = new Appointment(
                        rs.getInt("Appointment_ID"),
                        rs.getString("Title"),
                        rs.getString("Description"),
                        rs.getString("Location"),
                        rs.getString("Type"),
                        rs.getDate("Start").toLocalDate(),
                        rs.getTimestamp("Start").toLocalDateTime(),
                        rs.getDate("End").toLocalDate(),
                        rs.getTimestamp("End").toLocalDateTime(),
                        rs.getInt("Customer_ID"),
                        rs.getInt("User_ID"),
                        rs.getInt("Contact_ID"));
                        
                appts.add(newAppt);
            }
            return appts;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        }
    }

    /** Creates Appointment
     * @param conName String value of Appointment Contact Name
     * @param title String value of Appointment Title
     * @param description String value of Appointment Description
     * @param location String value of Appointment Location
     * @param type String value of Appointment Type
     * @param start LocalDateTime value of Appointment Start
     * @param end LocalDateTime value of Appointment End
     * @param customerId Int value of Customer ID
     * @param userID Int value of User ID
     * @return Boolean Returns true if the appointment was created and false if creation failed
     * @throws SQLException Catches SQLException, prints stacktrace, and error message.
     */
    public static boolean createAppt(String conName, String title, String description, String location, String type, LocalDateTime start, LocalDateTime end, Integer customerId, Integer userID) throws SQLException 
    {

        Contact con = ContactQuery.getContactId(conName);

        String iStatement = "INSERT INTO appointments(Title, Description, Location, Type, Start, End, Customer_ID, Contact_ID, User_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        PSQuery.setPS(JDBC.getConn(), iStatement);
        PreparedStatement ps = PSQuery.getPS();

        ps.setString(1, title);
        ps.setString(2, description);
        ps.setString(3, location);
        ps.setString(4, type);
        ps.setTimestamp(5, Timestamp.valueOf(start));
        ps.setTimestamp(6, Timestamp.valueOf(end));
        ps.setInt(7, customerId);
        ps.setInt(8, con.getContactId());
        ps.setInt(9, userID);

        try {
            ps.execute();
            if (ps.getUpdateCount() > 0) {
                System.out.println("Rows affected: " + ps.getUpdateCount());
            } else {
                System.out.println("No change");
            }
            return true;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }

    /** Deletes an Appointment by Appointment ID
     * @param apptId Int value of Appointment ID
     * @return Boolean Returns true if the appointment was successfully deleted and false if the appointment deletion failed
     * @throws SQLException Catches SQLException, prints stacktrace, and error message.
     */
    public static boolean deleteAppt(int apptId) throws SQLException 
    {
        String iStatement = "DELETE from appointments WHERE Appointment_Id=?";

        PSQuery.setPS(JDBC.getConn(), iStatement);
        PreparedStatement ps = PSQuery.getPS();

        ps.setInt(1, apptId);

        try {
            ps.execute();
            if (ps.getUpdateCount() > 0) {
                System.out.println("Rows affected: " + ps.getUpdateCount());
            } else {
                System.out.println("No change");
            }
            return true;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }

    /** Updates Appointment by Appointment ID
     * @param conName String value of Appointment Contact Name
     * @param title String value of Appointment Title
     * @param descrp String value of Appointment Description
     * @param loc String value of Appointment Location
     * @param type String value of Appointment Type
     * @param start LocalDateTime value of Appointment Start
     * @param end LocalDateTime value of Appointment End
     * @param customerId Int value of Customer ID
     * @param userID Int value of User ID
     * @param apptID Int value of Appointment ID
     * @return Boolean Returns true if the appointment was successfully updated and false if the appointment update failed
     * @throws SQLException Catches SQLException, prints stacktrace, and error message.
     */
    public static boolean updateAppt(String conName, String title, String descrp, String loc, String type, LocalDateTime start, LocalDateTime end, Integer customerId, Integer userID, Integer apptID) throws SQLException {
        Contact con = ContactQuery.getContactId(conName);

        String uStatement = "UPDATE appointments SET Title=?, Description=?, Location=?, Type=?, Start=?, End=?, Customer_ID=?, Contact_ID=?, User_ID=? WHERE Appointment_ID = ?;";

        PSQuery.setPS(JDBC.getConn(), uStatement);
        PreparedStatement ps = PSQuery.getPS();

        ps.setString(1, title);
        ps.setString(2, descrp);
        ps.setString(3, loc);
        ps.setString(4, type);
        ps.setTimestamp(5, Timestamp.valueOf(start));
        ps.setTimestamp(6, Timestamp.valueOf(end));
        ps.setInt(7, customerId);
        ps.setInt(8, con.getContactId());
        ps.setInt(9, userID);
        ps.setInt(10, apptID);
        

        try {
            ps.execute();
            if (ps.getUpdateCount() > 0) {
                System.out.println("Rows affected: " + ps.getUpdateCount());
            } else {
                System.out.println("No change");
            }
            return true;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }

    /** Gets Appointment by Customer ID
     * @param custId Int value of Customer ID
     * @return ObservableList List of Appointments
     * @throws SQLException Catches SQLException, prints stacktrace, and error message.
     */
    public static ObservableList<Appointment> getApptsByCustID(int custId) throws SQLException {
        ObservableList<Appointment> appts = FXCollections.observableArrayList();

        String qStatement = "SELECT * FROM appointments AS a INNER JOIN contacts AS c ON a.Contact_ID=c.Contact_ID WHERE Customer_ID=?;";

        PSQuery.setPS(JDBC.getConn(), qStatement);
        PreparedStatement ps = PSQuery.getPS();

        ps.setInt(1, custId);

        try {
            ps.execute();
            ResultSet rs = ps.getResultSet();

            
            while (rs.next()) 
            {
                Appointment newAppt = new Appointment(
                        rs.getInt("Appointment_ID"),
                        rs.getString("Title"),
                        rs.getString("Description"),
                        rs.getString("Location"),
                        rs.getString("Type"),
                        rs.getDate("Start").toLocalDate(),
                        rs.getTimestamp("Start").toLocalDateTime(),
                        rs.getDate("End").toLocalDate(),
                        rs.getTimestamp("End").toLocalDateTime(),
                        rs.getInt("Customer_ID"),
                        rs.getInt("User_ID"),
                        rs.getInt("Contact_ID"));
                        
                appts.add(newAppt);
            }
            return appts;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        }
    }

    /** Gets Appointment by Contact ID
     * @param conID Int value of Contact ID
     * @return ObservableList List of Appointments
     * @throws SQLException Catches SQLException, prints stacktrace, and error message.
     */
    public static ObservableList<Appointment> getApptByContID(int conID) throws SQLException {
        ObservableList<Appointment> appts = FXCollections.observableArrayList();

        String qStatement = "SELECT * FROM appointments AS a INNER JOIN contacts AS c ON a.Contact_ID=c.Contact_ID WHERE a.Contact_ID=?;";

        PSQuery.setPS(JDBC.getConn(), qStatement);
        PreparedStatement ps = PSQuery.getPS();

        ps.setInt(1, conID);

        try {
            ps.execute();
            ResultSet rs = ps.getResultSet();

            
            while (rs.next()) 
            {
                Appointment newAppt = new Appointment(
                        rs.getInt("Appointment_ID"),
                        rs.getString("Title"),
                        rs.getString("Description"),
                        rs.getString("Location"),
                        rs.getString("Type"),
                        rs.getDate("Start").toLocalDate(),
                        rs.getTimestamp("Start").toLocalDateTime(),
                        rs.getDate("End").toLocalDate(),
                        rs.getTimestamp("End").toLocalDateTime(),
                        rs.getInt("Customer_ID"),
                        rs.getInt("User_ID"),
                        rs.getInt("Contact_ID"));
                        
                appts.add(newAppt);
            }
            return appts;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        }
    }
    /**
     * Gets ObservableList of users
     * @param userId Int User Id
     * @return ObservableList of users
     * @throws SQLException Catches SQLException, prints stacktrace, and error message.
     */
    public static ObservableList<Appointment> getApptsByUserID(int userId) throws SQLException {
        ObservableList<Appointment> appts = FXCollections.observableArrayList();

        String qs = "SELECT * FROM appointments AS a INNER JOIN users AS u ON a.User_ID=u.User_ID WHERE a.User_ID=?;";

        PSQuery.setPS(JDBC.getConn(), qs);
        PreparedStatement ps = PSQuery.getPS();

        ps.setInt(1, userId);

        try {
            ps.execute();
            ResultSet rs = ps.getResultSet();

            
            while (rs.next()) 
            {
                Appointment newAppt = new Appointment(
                        rs.getInt("Appointment_ID"),
                        rs.getString("Title"),
                        rs.getString("Description"),
                        rs.getString("Location"),
                        rs.getString("Type"),
                        rs.getDate("Start").toLocalDate(),
                        rs.getTimestamp("Start").toLocalDateTime(),
                        rs.getDate("End").toLocalDate(),
                        rs.getTimestamp("End").toLocalDateTime(),
                        rs.getInt("Customer_ID"),
                        rs.getInt("User_ID"),
                        rs.getInt("Contact_ID"));
                        
                appts.add(newAppt);
            }
            return appts;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        }
    }

    /** Gets Appointment by Appointment ID
     * @param ApptID Int value of Appointment ID
     * @return list of appointments 
     * @throws SQLException Catches SQLException, prints stacktrace, and error message.
     */
    public static Appointment getApptByApptID(int ApptID) throws SQLException 
    {

        String qStatement = "SELECT * FROM appointments AS a INNER JOIN contacts AS c ON a.Contact_ID=c.Contact_ID WHERE Appointment_ID=?;";

        PSQuery.setPS(JDBC.getConn(), qStatement);
        PreparedStatement ps = PSQuery.getPS();

        ps.setInt(1, ApptID);

        try {
            ps.execute();
            ResultSet rs = ps.getResultSet();

            
            while (rs.next()) 
            {
                Appointment newAppt = new Appointment(
                        rs.getInt("Appointment_ID"),
                        rs.getString("Title"),
                        rs.getString("Description"),
                        rs.getString("Location"),
                        rs.getString("Type"),
                        rs.getDate("Start").toLocalDate(),
                        rs.getTimestamp("Start").toLocalDateTime(),
                        rs.getDate("End").toLocalDate(),
                        rs.getTimestamp("End").toLocalDateTime(),
                        rs.getInt("Customer_ID"),
                        rs.getInt("User_ID"),
                        rs.getInt("Contact_ID"));
                        
                return newAppt;
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return null;
    }
}
 