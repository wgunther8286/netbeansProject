/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBQuery;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import DBQuery.*;
import Model.*;
import Helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Query for Divisions
 * @author William Gunther
 */
public class DivQuery 
{
    /**
     * Gets ObservableList of Divisions
     * @return divs
     * @throws SQLException Catches SQLException, prints error message. 
     */
    public static ObservableList<Division> getDivs() throws SQLException 
    {
        ObservableList<Division> divs = FXCollections.observableArrayList();

        String qs = "SELECT * FROM first_level_divisions;";

        PSQuery.setPS(JDBC.getConn(), qs);
        PreparedStatement ps = PSQuery.getPS();

        try {
            ps.execute();
            ResultSet rs = ps.getResultSet();

            while (rs.next()) 
            {

                Division newD = new Division(
                        rs.getInt("Division_ID"),
                        rs.getString("Division"),
                        rs.getInt("COUNTRY_ID"));
                

                divs.add(newD);
            }
            return divs;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        }
    }

    /** Gets Division by the Division Name
     * @param division String value of Division Name
     * @return Division Division Object
     * @throws SQLException Catches SQLException and prints stacktrace.
     */
    public static Division getDivId(String division) throws SQLException 
    {
        String qs = "SELECT * FROM first_level_divisions WHERE Division=?";

        PSQuery.setPS(JDBC.getConn(), qs);
        PreparedStatement ps = PSQuery.getPS();

        ps.setString(1, division);

        try {
            ps.execute();
            ResultSet rs = ps.getResultSet();

            while (rs.next()) 
            {
                Division newD = new Division(
                        rs.getInt("Division_ID"),
                        rs.getString("Division"),
                        rs.getInt("COUNTRY_ID")
                );
                return newD;
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return null;
    }

    /** Gets Divisions by Country
     * @param country String value of Country Name
     * @return ObservableList List containing Division Objects
     * @throws SQLException Catches SQLException and prints stacktrace.
     */
    public static ObservableList<Division> getDivByCountry(String country) throws SQLException 
    {
        Country newC = CountriesQuery.getCountryId(country);

        ObservableList<Division> divisions = FXCollections.observableArrayList();

        String qs = "SELECT * FROM first_level_divisions WHERE COUNTRY_ID=?;";

        PSQuery.setPS(JDBC.getConn(), qs);
        PreparedStatement ps = PSQuery.getPS();

        ps.setInt(1, newC.getId());

        try {
            ps.execute();
            ResultSet rs = ps.getResultSet();

            
            while (rs.next()) 
            {

                Division newD = new Division(
                        rs.getInt("Division_ID"),
                        rs.getString("Division"),
                        rs.getInt("COUNTRY_ID")
                );

                divisions.add(newD);
            }
            return divisions;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        }
    }
    
}
