/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBQuery;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import DBQuery.*;
import Model.*;
import Helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Query for Customers
 * @author r3j20
 */
public class CustQuery 
{
    /**
     * Gets list of customers
     * @return customers
     * @throws SQLException Catches SQLException, prints error message. 
     */
    public static ObservableList<Customer> getCustomers() throws SQLException 
    {
        ObservableList<Customer> customers = FXCollections.observableArrayList();

        String ss = "SELECT * FROM customers AS c INNER JOIN first_level_divisions AS d ON c.Division_ID = d.Division_ID INNER JOIN countries AS co ON co.Country_ID=d.COUNTRY_ID;";

        PSQuery.setPS(JDBC.getConn(), ss);
        PreparedStatement ps = PSQuery.getPS();

        try {
            ps.execute();
            ResultSet rs = ps.getResultSet();

            
            while (rs.next()) 
            {

                Customer newC = new Customer(
                        rs.getInt("Customer_ID"),
                        rs.getString("Customer_Name"),
                        rs.getString("Address"),
                        rs.getString("Postal_Code"),
                        rs.getString("Phone"),
                        rs.getString("Division"),
                        rs.getString("Country"),
                        rs.getInt("Division_ID")
                        );

                customers.add(newC);
            }
            return customers;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        }
    }

    /** Creates a new Customer
     * @param name String value of Customer Name
     * @param address String value of Customer Address
     * @param postalCode String value of Customer Postal Code
     * @param phone String value of Customer Phone Number
     * @param division String value of Division Name
     * @return Boolean Returns true if the customer was successfully created and false if the customer creation failed
     * @throws SQLException Catches SQLException, prints stacktrace, and error message.
     */
    public static boolean createCustomer(String name, String address, String postalCode, String phone, String division) throws SQLException 
    {

        Division newD = DivQuery.getDivId(division);

        String is = "INSERT INTO customers(Customer_Name, Address, Postal_Code, Phone, Division_ID) VALUES (?, ?, ?, ?, ?)";

        PSQuery.setPS(JDBC.getConn(), is);
        PreparedStatement ps = PSQuery.getPS();

        ps.setString(1, name);
        ps.setString(2, address);
        ps.setString(3, postalCode);
        ps.setString(4, phone);
        ps.setInt(5, newD.getDivisionId());

        try {
            ps.execute();
            if (ps.getUpdateCount() > 0) {
                System.out.println("Rows affected: " + ps.getUpdateCount());
            } else {
                System.out.println("No change");
            }
            return true;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }

    /** Updates existing Customer by Customer ID
     * @param customerId Int value of Customer ID
     * @param name String value of Customer Name
     * @param address String value of Customer Address
     * @param postalCode String value of Customer Postal Code
     * @param phone String value of Customer Phone Number
     * @param division String value of Division Name
     * @return Boolean Returns true if the customer was successfully updated and false if the customer update failed
     * @throws SQLException Catches SQLException, prints stacktrace, and error message.
     */
    public static boolean updateCustomer(int customerId, String name, String address, String postalCode, String phone, String division) throws SQLException {
        Division newD = DivQuery.getDivId(division);

        String is = "UPDATE customers SET Customer_Name=?, Address=?, Postal_Code=?, Phone=?, Division_ID=? WHERE Customer_ID=?";

        PSQuery.setPS(JDBC.getConn(), is);
        PreparedStatement ps = PSQuery.getPS();

        ps.setString(1, name);
        ps.setString(2, address);
        ps.setString(3, postalCode);
        ps.setString(4, phone);
        ps.setInt(5, newD.getDivisionId());
        ps.setInt(6, customerId);
        

        try {
            ps.execute();
            if (ps.getUpdateCount() > 0) {
                System.out.println("Rows affected: " + ps.getUpdateCount());
            } else {
                System.out.println("No change");
            }
            return true;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }

    /**Deletes an existing Customer
     * @param custId Int of Customer ID
     * @return Boolean Returns true if the customer was successfully deleted and false if the customer deletion failed
     * @throws SQLException Catches SQLException, prints stacktrace, and error message.
     */
    public static boolean deleteCustomer(int custId) throws SQLException {
        String is = "DELETE from customers WHERE Customer_Id=?";

        PSQuery.setPS(JDBC.getConn(), is);
        PreparedStatement ps = PSQuery.getPS();

        ps.setInt(1, custId);

        try {
            ps.execute();
            if (ps.getUpdateCount() > 0) {
                System.out.println("Rows affected: " + ps.getUpdateCount());
            } else {
                System.out.println("No change");
            }
            return true;
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            return false;
        }
    }

    
}
