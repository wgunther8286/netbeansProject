/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBQuery;
import Helper.JDBC;
import Model.Country;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

/**
 * Query for Countries
 * @author William Gunther
 */
public class CountriesQuery 
{
    /**
     * Gets List of all Countries
     * @return countries
     * @throws SQLException Catches SQLException and prints error message. 
     */
    public static ObservableList<Country> getCountries() throws SQLException 
    {
        ObservableList<Country> countries = FXCollections.observableArrayList();

        String ss = "SELECT * FROM countries;";

        PSQuery.setPS(JDBC.getConn(), ss);
        PreparedStatement ps = PSQuery.getPS();

        try {
            ps.execute();
            ResultSet rs = ps.getResultSet();

            while (rs.next()) 
            {

                Country newC = new Country(
                        rs.getInt("Country_ID"),
                        rs.getString("Country"));
                
                countries.add(newC);
            }
            return countries;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return null;
        }
    }

    /** Gets a Country by Country Name
     * @param country String value of Country Name
     * @return Country Country Object
     * @throws SQLException Catches SQLException and prints stacktrace.
     */
    public static Country getCountryId(String country) throws SQLException 
    {

        String qStatement = "SELECT * FROM countries WHERE Country=?";

        PSQuery.setPS(JDBC.getConn(), qStatement);
        PreparedStatement ps = PSQuery.getPS();

        ps.setString(1, country);

        try {
            ps.execute();
            ResultSet rs = ps.getResultSet();

            while (rs.next()) 
            {
                Country newC = new Country(
                        rs.getInt("Country_ID"),
                        rs.getString("Country"));
                
                return newC;
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return null;
    }
    
}
