/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBQuery;

import Helper.JDBC;
import Model.Contact;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.*;

/**
 * Query for Contacts
 * @author r3j20
 */
public class ContactQuery 
{
  /** Gets a list of Contacts and Appointments joined by the Contact ID
     * @return ObservableList Returns list of Contacts
     * @throws Exception Catches Exception, prints stacktrace, and error message.
     */
    public static ObservableList<Contact> getContacts() throws Exception 
    {
        
        ObservableList<Contact> contactLs = FXCollections.observableArrayList();
       
       try {
       
        
        String sqlStmt = "SELECT co.contact_Name, co.contact_ID from contacts co";
        
        PreparedStatement ps = JDBC.getConn().prepareStatement(sqlStmt);
        ResultSet rs = ps.executeQuery();
        
        while(rs.next()) 
        {
            
            int conID = rs.getInt("Contact_ID");
            String conName = rs.getString("contact_Name");

            contactLs.add(new Contact(conID,conName));
        }
  
        }
        catch(Exception ex) {
        System.out.println("Error: " + ex.getMessage());
        }
    return contactLs;
    }
   
    /** Gets Contact  by the Contact Name
     * @param conName String value of Contact Name
     * @return Contact Returns Contact
     * @throws SQLException Catches SQLException, prints stacktrace, and error message.
     */
    public static Contact getContactId(String conName) throws SQLException 
    {
        String qStatement = "SELECT * FROM contacts WHERE Contact_Name=?";

        PSQuery.setPS(JDBC.getConn(), qStatement);
        PreparedStatement ps = PSQuery.getPS();

        ps.setString(1, conName);


        try {
            ps.execute();
            ResultSet rs = ps.getResultSet();;

            
            while (rs.next()) 
            {
                Contact newContact = new Contact(
                        rs.getInt("Contact_ID"),
                        rs.getString("Contact_Name"),
                        rs.getString("Email"));
                
                return newContact;
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return null;
    }
}
