/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controller;

import DBQuery.ApptQuery;
import Model.Appointment;
import Model.Contact;
import DBQuery.*;
import Model.Customer;
import Model.User;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.*;
import java.time.chrono.ChronoZonedDateTime;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.sql.*;

/**
 * FXML Controller class
 *
 * @author r3j20
 */

/**
 * Create Appointment Controller class
 * 
 */
public class Create_Appointment_Controller implements Initializable {
    
    @FXML
    private ComboBox<String> cboContact;

    @FXML
    private ComboBox<String> cboETime;

    @FXML
    private ComboBox<String> cboSTime;
    
    @FXML
    private ComboBox<Integer> cboCustId;
     
    @FXML
    private ComboBox<String> cboType;

    @FXML
    private ComboBox<Integer> cboUserId;

    @FXML
    private DatePicker dpEDate;

    @FXML
    private DatePicker dpSDate;

    

    @FXML
    private Label lblContact;

    @FXML
    private Label lblCustId;

    @FXML
    private Label lblDescrip;

    @FXML
    private Label lblEDate;

    @FXML
    private Label lblETime;

    @FXML
    private Label lblLoc;

    @FXML
    private Label lblSDate;

    @FXML
    private Label lblSTime;

    @FXML
    private Label lblTitle;

    @FXML
    private Label lblType;

    @FXML
    private Label lblUserId;
    
    @FXML
    private TextField txtApptID;

    @FXML
    private TextField txtDescrip;

    @FXML
    private TextField txtLoc;

    @FXML
    private TextField txtTitle;

    @FXML
    private TextField txtType;

    @FXML
    private TextField txtUserId;
    
    private ZonedDateTime STimeConv;
    private ZonedDateTime ETimeConv;
    
    private ZonedDateTime timeToEST(LocalDateTime time) 
    {
        return ZonedDateTime.of(time,ZoneId.of("America/New_York"));
    }
    
    @FXML
    void btnBack(ActionEvent event) throws IOException 
    {
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Are you sure you want to go back?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) 
        {
            Parent parent = FXMLLoader.load(getClass().getResource("/View/Appointments_View.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();

    }
    }
    
    @FXML
    void btnCust(ActionEvent event) throws IOException 
    {
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Are you sure you want to go to the Customer Screen?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) 
        {
            Parent parent = FXMLLoader.load(getClass().getResource("/View/Customer_View.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();

    }
    }

    

    @FXML
    void btnExit(ActionEvent event) throws IOException 
    {
        
        Main_Controller.alertWindow(4);
        
    }
    

    
    @FXML
    void btnSignOut(ActionEvent event) throws IOException 
    {
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Are you sure you want to Sign Out?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) 
        {
            Parent parent = FXMLLoader.load(getClass().getResource("/View/Login_View.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }

    }
    
    
    /**
     * 
     * @param event
     * @throws SQLException
     * @throws IOException 
     * Creates new Appointment, checks that all text fields are filled.
     */
     @FXML
    void btnSave(ActionEvent event) throws SQLException, IOException 
    {
        boolean filled = checkAppt (
                txtTitle.getText(),
                txtDescrip.getText(),
                txtLoc.getText());
                
                

        if (filled) 
        {
            try {
                boolean isFilled = ApptQuery.createAppt(
                        cboContact.getSelectionModel().getSelectedItem(),
                        txtTitle.getText(),
                        txtDescrip.getText(),
                        txtLoc.getText(),
                        cboType.getSelectionModel().getSelectedItem(),
                        LocalDateTime.of(dpSDate.getValue(), LocalTime.parse(cboSTime.getSelectionModel().getSelectedItem())),
                        LocalDateTime.of(dpEDate.getValue(), LocalTime.parse(cboETime.getSelectionModel().getSelectedItem())), 
                        cboCustId.getSelectionModel().getSelectedItem(),
                        cboUserId.getSelectionModel().getSelectedItem());
                        

                if (isFilled) 
                {
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "New Appointment Created");
                    Optional<ButtonType> result = alert.showAndWait();

                    if (result.isPresent() && (result.get() ==  ButtonType.OK)) 
                    {
                        try {
                            Parent parent = FXMLLoader.load(getClass().getResource("/View/Appointments_View.fxml"));
                            Scene scene = new Scene(parent);
                            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                            stage.setScene(scene);
                            stage.show();
                        } catch (Exception e) {
                            e.printStackTrace();
                            Main_Controller.alertWindow(14);
                        }
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Appointment not saved");
                    Optional<ButtonType> result = alert.showAndWait();

                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    /** Fills Time cbo with Time List
     */
    private void fillcboTime() {
        ObservableList<String> newTime = FXCollections.observableArrayList();
        LocalTime sTime = LocalTime.of(7, 0);
        LocalTime eTime = LocalTime.of(23, 0);

        newTime.add(sTime.toString());
        while (sTime.isBefore(eTime)) {
            sTime = sTime.plusMinutes(15);
            newTime.add(sTime.toString());
        }

        cboSTime.setItems(newTime);
        cboETime.setItems(newTime);
    }

    /** Fills Contact cbo with Contacts List
     */
    private void fillCBOContact() {
        ObservableList<String> cboContactLs = FXCollections.observableArrayList();

        try {
            ObservableList<Contact> contacts = ContactQuery.getContacts();
            if (contacts != null){
                for (Contact contact: contacts) {
                    if (!cboContactLs.contains(contact.getContactName())) {
                        cboContactLs.add(contact.getContactName());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        cboContact.setItems(cboContactLs);
    }

    /** Fills Customer ID cbo with Customer ID List
     */
    private void fillCboCustId() {
        ObservableList<Integer> cboCustIdLs = FXCollections.observableArrayList();

        try {
            ObservableList<Customer> customers = CustQuery.getCustomers();
            if (customers != null) {
                for (Customer customer: customers) {
                    cboCustIdLs.add(customer.getCustomerId());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        cboCustId.setItems(cboCustIdLs);
    }
    
    

    /** Fills User ID cbo with User ID List
     */
    private void fillCboUserId() {
        ObservableList<Integer> cboUserIdLs = FXCollections.observableArrayList();

        try {
            ObservableList<User> users = UserQuery.getUsers();
            if (users != null) {
                for (User user: users) {
                    cboUserIdLs.add(user.getUserId());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        cboUserId.setItems(cboUserIdLs);
    }

    /** Fills Type cbo with Type List
     */
    private void fillCboType() {
        ObservableList<String> cboTypeLs = FXCollections.observableArrayList();

        cboTypeLs.addAll("Planning Session", "De-Briefing", "Intake", "Pre-Briefing", "Open Session");

        cboType.setItems(cboTypeLs);
    }
    
    
    /** Checks Appt Fields are filled and not empty
     * Throws alert if fields are not selected, if fields are empty, if appts overlap, and if appt is outside of business hours
     * @param title String value of Appointment Title
     * @param descrip String value of Appointment Description
     * @param loc String value of Appointment Location
     * @return Boolean Returns true if filled and false if not filled
     */
    private boolean checkAppt(String title, String descrip, String loc) throws IOException
    {
        if (cboContact.getSelectionModel().isEmpty())
        {
            Main_Controller.alertWindow(15);
            return false;
        }

        if (title.isEmpty())
        {
            Main_Controller.alertWindow(16);
            return false;
        }

        if (descrip.isEmpty())
        {
            Main_Controller.alertWindow(17);
            return false;
        }

        if (loc.isEmpty())
        {
            Main_Controller.alertWindow(18);
            return false;
        }

        
        if  (cboType.getSelectionModel().isEmpty()) 
        {
            Main_Controller.alertWindow(28);
            return false;
        }

        if (dpSDate.getValue() == null) 
        {
            Main_Controller.alertWindow(19);
            return false;
        }

        if (cboSTime.getSelectionModel().isEmpty())
        {
            Main_Controller.alertWindow(19);
            return false;
        }

        if (dpEDate.getValue() == null)
        {
            Main_Controller.alertWindow(20);
            return false;
        }

        if (dpEDate.getValue().isBefore(dpSDate.getValue())) 
        {
            Main_Controller.alertWindow(23);
            return false;
        }

        if (cboETime.getSelectionModel().isEmpty())
        {
            Main_Controller.alertWindow(20);
            return false;
        }

        if (cboCustId.getSelectionModel().getSelectedItem() == null) 
        {
            Main_Controller.alertWindow(21);
            return false;
        }

        if  (cboUserId.getSelectionModel().isEmpty()) 
        {
            Main_Controller.alertWindow(22);
            return false;
        }

        

        LocalTime sTime = LocalTime.parse(cboSTime.getSelectionModel().getSelectedItem());
        LocalTime eTime = LocalTime.parse(cboETime.getSelectionModel().getSelectedItem());

        if (eTime.isBefore(sTime)) 
        {
            Main_Controller.alertWindow(24);
            return false;
        };

        LocalDate sDate = dpSDate.getValue();
        LocalDate eDate = dpEDate.getValue();

        if (!sDate.equals(eDate))
        {
            Main_Controller.alertWindow(25);
            return false;
        };

        

        LocalDateTime selStart = sDate.atTime(sTime);
        LocalDateTime selEnd = eDate.atTime(eTime);

        LocalDateTime proApptStart;
        LocalDateTime proApptEnd;


        try {
            ObservableList<Appointment> appointments = ApptQuery.getApptsByCustID(cboCustId.getSelectionModel().getSelectedItem());
            for (Appointment appointment: appointments) 
            {
                proApptStart = appointment.getSDate().atTime(appointment.getSTime().toLocalTime());
                proApptEnd = appointment.getEDate().atTime(appointment.getETime().toLocalTime());

                if (proApptStart.isAfter(selStart) && proApptStart.isBefore(selEnd)) 
                {
                    Main_Controller.alertWindow(26);
                    return false;
                } else if (proApptEnd.isAfter(selStart) && proApptEnd.isBefore(selEnd)) 
                {
                    Main_Controller.alertWindow(26);
                    return false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        
        STimeConv = timeToEST(LocalDateTime.of(dpSDate.getValue(), LocalTime.parse(cboSTime.getSelectionModel().getSelectedItem())));
        ETimeConv = timeToEST(LocalDateTime.of(dpEDate.getValue(), LocalTime.parse(cboETime.getSelectionModel().getSelectedItem())));

        if (STimeConv.toLocalTime().isAfter(LocalTime.of(22, 0))) 
        {
            Main_Controller.alertWindow(27);
            return false;
        }

        if (ETimeConv.toLocalTime().isAfter(LocalTime.of(22, 0))) 
        {
            Main_Controller.alertWindow(27);
            return false;
        }

        if (STimeConv.toLocalTime().isBefore(LocalTime.of(8, 0))) 
        {
            Main_Controller.alertWindow(27);
            return false;
        }

        if (ETimeConv.toLocalTime().isBefore(LocalTime.of(8, 0))) 
        {
            Main_Controller.alertWindow(27);
            return false;
        }

        return true;
    }
    

    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        fillcboTime();
        fillCBOContact();
        fillCboCustId();
        fillCboUserId();
        fillCboType();
        
    }    
    
}

