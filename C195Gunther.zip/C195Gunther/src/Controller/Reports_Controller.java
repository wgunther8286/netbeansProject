/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controller;

import DBQuery.ApptQuery;
import DBQuery.ContactQuery;
import DBQuery.UserQuery;
import Model.Appointment;
import Model.Contact;
import Model.User;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Month;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author r3j20
 */
public class Reports_Controller implements Initializable 
{
    
    @FXML
    private ComboBox<Integer> cboContact;

    @FXML
    private ComboBox<String> cboCountry;

    
    @FXML
    private RadioButton rbApptsMonth;

    @FXML
    private RadioButton rbApptsType;

    @FXML
    private RadioButton rbContactSche;

    @FXML
    private ComboBox<Integer> cboUserId;

    @FXML
    private ToggleGroup tgReports;
    
    @FXML
    private void btnExit(ActionEvent event) throws IOException 
    {
        
        Main_Controller.alertWindow(4);
        
    }
    
    /**
     * Generates a report in the form of an Information Alert.
     * Report is based on which radio button is selected, type or month.
     * Report will list all appointments by type or month based on the respective radio button selection.
     * @param event 
     */
    @FXML
    void btnMonthTypeReport(ActionEvent event) 
    {
        
        ObservableList<String> plan = FXCollections.observableArrayList();
        ObservableList<String> dbrf = FXCollections.observableArrayList();
        ObservableList<String> intk = FXCollections.observableArrayList();
        ObservableList<String> pbrf = FXCollections.observableArrayList();
        ObservableList<String> open = FXCollections.observableArrayList();

        ObservableList<Integer> jan = FXCollections.observableArrayList();
        ObservableList<Integer> feb = FXCollections.observableArrayList();
        ObservableList<Integer> mar = FXCollections.observableArrayList();
        ObservableList<Integer> apr = FXCollections.observableArrayList();
        ObservableList<Integer> may = FXCollections.observableArrayList();
        ObservableList<Integer> june = FXCollections.observableArrayList();
        ObservableList<Integer> july = FXCollections.observableArrayList();
        ObservableList<Integer> aug = FXCollections.observableArrayList();
        ObservableList<Integer> sept = FXCollections.observableArrayList();
        ObservableList<Integer> oct = FXCollections.observableArrayList();
        ObservableList<Integer> nov = FXCollections.observableArrayList();
        ObservableList<Integer> dec = FXCollections.observableArrayList();

        try {
            ObservableList<Appointment> appts = ApptQuery.getAppts();

            if (appts != null) 
            {
                for (Appointment appt : appts) 
                {
                    String type = appt.getType();
                    LocalDate date = appt.getSDate();

                    if (type.equals("Planning Session")) 
                    {
                        plan.add(type);
                    }

                    if (type.equals("De-Briefing")) 
                    {
                        dbrf.add(type);
                    }

                    if (type.equals("Intake")) 
                    {
                        intk.add(type);
                    }

                    if (type.equals("Pre-Briefing")) 
                    {
                        pbrf.add(type);
                    }

                    if (type.equals("Open Session")) 
                    {
                        open.add(type);
                    }

                    if (date.getMonth().equals(Month.of(1))) 
                    {
                        jan.add(date.getMonthValue());
                    }

                    if (date.getMonth().equals(Month.of(2))) 
                    {
                        feb.add(date.getMonthValue());
                    }

                    if (date.getMonth().equals(Month.of(3))) 
                    {
                        mar.add(date.getMonthValue());
                    }

                    if (date.getMonth().equals(Month.of(4))) 
                    {
                        apr.add(date.getMonthValue());
                    }

                    if (date.getMonth().equals(Month.of(5))) 
                    {
                        may.add(date.getMonthValue());
                    }

                    if (date.getMonth().equals(Month.of(6))) 
                    {
                        june.add(date.getMonthValue());
                    }

                    if (date.getMonth().equals(Month.of(7))) 
                    {
                        july.add(date.getMonthValue());
                    }

                    if (date.getMonth().equals(Month.of(8))) 
                    {
                        aug.add(date.getMonthValue());
                    }

                    if (date.getMonth().equals(Month.of(9))) 
                    {
                        sept.add(date.getMonthValue());
                    }

                    if (date.getMonth().equals(Month.of(10))) 
                    {
                        oct.add(date.getMonthValue());
                    }

                    if (date.getMonth().equals(Month.of(11))) 
                    {
                        nov.add(date.getMonthValue());
                    }

                    if (date.getMonth().equals(Month.of(12))) 
                    {
                        dec.add(date.getMonthValue());
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        if (rbApptsType.isSelected()) 
        {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Appointment Count by Type:");
            alert.setContentText("Appointments by Type: " +
                    "\nPlanning Session: " + plan.size() +
                    "\nDe-Briefing: " + dbrf.size() +
                    "\nFollow-up: " + intk.size() +
                    "\nPre-Briefing: " + pbrf.size() +
                    "\nOpen Session: " + open.size());
            alert.setResizable(true);
            alert.showAndWait();
        }

        if (rbApptsMonth.isSelected()) 
        {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Report: Customer Appointment Count by Month");
            alert.setContentText("Total number of Customer Appointments by Month: " +
                    "\nJanuary: " + jan.size() +
                    "\nFebruary: " + feb.size() +
                    "\nMarch: " + mar.size() +
                    "\nApril: " + apr.size() +
                    "\nMay: " + may.size() +
                    "\nJune: " + june.size() +
                    "\nJuly: " + july.size() +
                    "\nAugust: " + aug.size() +
                    "\nSeptember: " + sept.size() +
                    "\nOctober: " + oct.size() +
                    "\nNovember: " + nov.size() +
                    "\nDecember: " + dec.size());
                    
            alert.showAndWait();
        }
    }

    

    @FXML
    private void btnBack(ActionEvent event) throws IOException 
    {
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Are you sure you want to go back?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) 
        {
            Parent parent = FXMLLoader.load(getClass().getResource("/View/Main_View.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();

    }
    }
    
    @FXML
    void btnReport2(ActionEvent event) 
    {
        
        Integer conID = cboContact.getSelectionModel().getSelectedItem();
        try {
            ObservableList<Appointment> appts = ApptQuery.getApptByContID(conID);


            if (appts != null) 
            {
                for (Appointment appt: appts) 
                {

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Appointment by Contact ID");
                    alert.setContentText("Appointments by Contact ID #" + conID + ": " +
                            "\nAppointment ID: " + appt.getApptId() +
                            "\nTitle: " + appt.getTitle() +
                            "\nType: " + appt.getType() +
                            "\nDescription: " + appt.getDescription() +
                            "\nStart Date: " + appt.getSDate() +
                            "\nStart Time: " + appt.getSTime() +
                            "\nEnd Date: " + appt.getEDate() +
                            "\nEnd Time: " + appt.getETime() +
                            "\nCustomer ID: " + appt.getCustomerId() +
                            "\nUser ID: " + appt.getUserId());
                    

                    alert.setResizable(true);
                    alert.showAndWait();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /** Fill Contact ID cbo with Contact ID List
     */
    private void fillCboConId() {
        ObservableList<Integer> cboConIdLs = FXCollections.observableArrayList();

        try {
            ObservableList<Contact> cons = ContactQuery.getContacts();
            if (cons != null) {
                for (Contact con: cons) {
                    if (!cboConIdLs.contains(con.getContactId())) {
                        cboConIdLs.add(con.getContactId());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        cboContact.setItems(cboConIdLs);
    }


    
    

    @FXML
    private void btnSignOut(ActionEvent event) throws IOException 
    {
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Are you sure you want to Sign Out?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) 
        {
            Parent parent = FXMLLoader.load(getClass().getResource("/View/Login_View.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }
    
    /** Fill User ID cbo with User ID List
     */
    private void fillCboUserId() {
        ObservableList<Integer> cboUserIdLs = FXCollections.observableArrayList();

        try {
            ObservableList<User> userId = UserQuery.getUsers();
            if (userId != null) {
                for (User user: userId) {
                    if (!cboUserIdLs.contains(user.getUserId())) {
                        cboUserIdLs.add(user.getUserId());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        cboUserId.setItems(cboUserIdLs);
    }
    
    @FXML
    void btnReport3(ActionEvent event) throws SQLException 
    {
        
        Integer userId = cboUserId.getSelectionModel().getSelectedItem();
        
        ObservableList<Integer> user1 = FXCollections.observableArrayList();
        ObservableList<Integer> user2 = FXCollections.observableArrayList();
        
        try {
            ObservableList<Appointment> appts = ApptQuery.getApptsByUserID(userId);

            if (appts != null) 
            {
                for (Appointment appt : appts) 
                {
                    int uId = appt.getUserId();
                    
                    if (uId == 1) 
                    {
                        user1.add(uId);
                         Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("User Appointment Count");
                    alert.setContentText("Total number of Appointments by User: " +
                    "\nUser 1: " + user1.size() +
                    "\nAppointment ID: " + appt.getApptId());
                   
                    alert.showAndWait();
                    }
                    
                    if (uId == 2) 
                    {
                        user2.add(uId);
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("User Appointment Count by Month");
                    alert.setContentText("Total number of Appointments by User: " +
                    
                    "\nUser 2: " + user2.size() +
                    "\nAppointment ID: " + appt.getApptId());
                    
                    alert.showAndWait();
                    }
               
                        
                }}
            
                
                } catch (Exception e) {
                    
                    
                    
            e.printStackTrace();
        }
        

    }
     
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        fillCboConId();
        fillCboUserId();
       
    }    
    
}
