/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controller;

/**
 * Update Appt controller
 */

import DBQuery.ApptQuery;
import DBQuery.ContactQuery;
import DBQuery.CustQuery;
import DBQuery.UserQuery;
import Model.Appointment;
import Model.Contact;
import Model.Customer;
import Model.User;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.TimeZone;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * Update appointment controller
 * @author r3j20
 */
public class Update_Appointment_Controller implements Initializable 
{

    /**
     * FXML Labels, text fields, combo boxes and date pickers.
     */
    @FXML
    private Label lblContact;
    @FXML
    private ComboBox<String> cboContact;
    @FXML
    private Label lblCustId;
    @FXML
    private ComboBox<Integer> cboCustId;
    @FXML
    private Label lblUserId;
    @FXML
    private TextField txtUserId;
    @FXML
    private Label lblTitle;
    @FXML
    private TextField txtTitle;
    @FXML
    private Label lblDescrip;
    @FXML
    private TextField txtDescrip;
    @FXML
    private Label lblLoc;
    @FXML
    private TextField txtLoc;
    @FXML
    private Label lblType;
    @FXML
    private TextField txtType;
    @FXML
    private Label lblSDate;
    @FXML
    private DatePicker dpSDate;
    @FXML
    private Label lblEDate;
    @FXML
    private DatePicker dpEDate;
    @FXML
    private Label lblSTime;
    @FXML
    private ComboBox<String> cboSTime;
    @FXML
    private Label lblETime;
    @FXML
    private ComboBox<String> cboETime;
    
    @FXML
    private ComboBox<String> cboType;

    @FXML
    private ComboBox<Integer> cboUserId;
    
    @FXML
    private ComboBox<Integer> cboApptId;

    
    private ZonedDateTime sTimeConv;
    private ZonedDateTime eTimeConv;
    
    /**
     * Constructor for time
     * @param t time to be converted
     * @return ZonedDateTime
     */
    private ZonedDateTime timeToEST(LocalDateTime t) 
    {
        return ZonedDateTime.of(t,ZoneId.of("America/New_York"));
    }

    
    private static Appointment selAppt;
    
    /**
     * Constructor for time conversion
     * @param t Local date time 
     * @param zId zone Id
     * @return ZDT 
     */
    private ZonedDateTime conToTimeZone(LocalDateTime t, String zId) 
    {
        return ZonedDateTime.of(t, ZoneId.of(zId));
    }
    /**
     * Receives the selected appt from the appointments view.
     * @param appt appointment passed to the selAppt object.
     */
     public static void rxSelAppt(Appointment appt) 
     {
        selAppt = appt;
    }

    @FXML
    private void btnCust(ActionEvent event) throws IOException 
    {
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Are you sure you want to go to the Customer Screen?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) 
        {
            Parent parent = FXMLLoader.load(getClass().getResource("/View/Customer_View.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
    }}

    @FXML
    private void btnSave(ActionEvent event) throws IOException 
    {
        
        boolean filled = checkAppt (
                txtTitle.getText(),
                txtDescrip.getText(),
                txtLoc.getText());
                
        if (filled) 
        {
            try {
                boolean isFilled = ApptQuery.updateAppt(
                        cboContact.getSelectionModel().getSelectedItem(),
                        txtTitle.getText(),
                        txtDescrip.getText(),
                        txtLoc.getText(),
                        cboType.getSelectionModel().getSelectedItem(),
                        LocalDateTime.of(dpSDate.getValue(), LocalTime.parse(cboSTime.getSelectionModel().getSelectedItem())),
                        LocalDateTime.of(dpEDate.getValue(), LocalTime.parse(cboETime.getSelectionModel().getSelectedItem())), 
                        cboCustId.getSelectionModel().getSelectedItem(),
                        cboUserId.getSelectionModel().getSelectedItem(),
                        cboApptId.getSelectionModel().getSelectedItem());
                        
                        

                if (isFilled) 
                {
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Successfully updated appointment: "
                            + "\n ApptId: " + selAppt.getApptId());
                    Optional<ButtonType> result = alert.showAndWait();

                    if (result.isPresent() && (result.get() ==  ButtonType.OK)) 
                    {
                        try {
                            Parent parent = FXMLLoader.load(getClass().getResource("/View/Appointments_View.fxml"));
                            Scene scene = new Scene(parent);
                            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                            stage.setScene(scene);
                            stage.show();
                        } catch (Exception e) {
                            e.printStackTrace();
                            Main_Controller.alertWindow(14);
                        }
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to update appointment");
                    Optional<ButtonType> result = alert.showAndWait();

                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Checks all fields are filled for the appointment
     * @param title appointment  title
     * @param descrip appointment description
     * @param loc appointment location
     * @return true if all fields are filled and valid
     * @throws IOException catches IOException
     */
    private boolean checkAppt(String title, String descrip, String loc) throws IOException
    {
        if (cboContact.getSelectionModel().isEmpty())
        {
            Main_Controller.alertWindow(15);
            return false;
        }

        if (title.isEmpty())
        {
            Main_Controller.alertWindow(16);
            return false;
        }

        if (descrip.isEmpty())
        {
            Main_Controller.alertWindow(17);
            return false;
        }

        if (loc.isEmpty())
        {
            Main_Controller.alertWindow(18);
            return false;
        }

        
        if  (cboType.getSelectionModel().isEmpty()) 
        {
            Main_Controller.alertWindow(28);
            return false;
        }

        if (dpSDate.getValue() == null) 
        {
            Main_Controller.alertWindow(19);
            return false;
        }

        if (cboSTime.getSelectionModel().isEmpty())
        {
            Main_Controller.alertWindow(19);
            return false;
        }

        if (dpEDate.getValue() == null)
        {
            Main_Controller.alertWindow(20);
            return false;
        }

        if (dpEDate.getValue().isBefore(dpSDate.getValue())) 
        {
            Main_Controller.alertWindow(23);
            return false;
        }

        if (cboETime.getSelectionModel().isEmpty())
        {
            Main_Controller.alertWindow(20);
            return false;
        }

        if (cboCustId.getSelectionModel().getSelectedItem() == null) 
        {
            Main_Controller.alertWindow(21);
            return false;
        }

        if  (cboUserId.getSelectionModel().isEmpty()) 
        {
            Main_Controller.alertWindow(22);
            return false;
        }

        LocalTime sTime = LocalTime.parse(cboSTime.getSelectionModel().getSelectedItem());
        LocalTime eTime = LocalTime.parse(cboETime.getSelectionModel().getSelectedItem());

        if (eTime.isBefore(sTime)) 
        {
            Main_Controller.alertWindow(24);
            return false;
        };

        LocalDate sDate = dpSDate.getValue();
        LocalDate eDate = dpEDate.getValue();

        if (!sDate.equals(eDate))
        {
            Main_Controller.alertWindow(25);
            return false;
        };
        
        LocalDateTime selStart = sDate.atTime(sTime);
        LocalDateTime selEnd = eDate.atTime(eTime);

        LocalDateTime proApptStart;
        LocalDateTime proApptEnd;

        try {
            ObservableList<Appointment> appts = ApptQuery.getApptsByCustID(cboCustId.getSelectionModel().getSelectedItem());
            for (Appointment appt: appts) 
            {
                proApptStart = appt.getSDate().atTime(appt.getSTime().toLocalTime());
                proApptEnd = appt.getEDate().atTime(appt.getETime().toLocalTime());

                if (proApptStart.isAfter(selStart) && proApptStart.isBefore(selEnd)) 
                {
                    Main_Controller.alertWindow(26);
                    return false;
                } else if (proApptEnd.isAfter(selStart) && proApptEnd.isBefore(selEnd)) 
                {
                    Main_Controller.alertWindow(26);
                    return false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        sTimeConv = timeToEST(LocalDateTime.of(dpSDate.getValue(), LocalTime.parse(cboSTime.getSelectionModel().getSelectedItem())));
        eTimeConv = timeToEST(LocalDateTime.of(dpEDate.getValue(), LocalTime.parse(cboETime.getSelectionModel().getSelectedItem())));

        if (sTimeConv.toLocalTime().isAfter(LocalTime.of(22, 0))) 
        {
            Main_Controller.alertWindow(27);
            return false;
        }

        if (eTimeConv.toLocalTime().isAfter(LocalTime.of(22, 0))) 
        {
            Main_Controller.alertWindow(27);
            return false;
        }

        if (sTimeConv.toLocalTime().isBefore(LocalTime.of(8, 0))) 
        {
            Main_Controller.alertWindow(27);
        }

        if (eTimeConv.toLocalTime().isBefore(LocalTime.of(8, 0))) 
        {
            Main_Controller.alertWindow(27);
            return false;
        }

        return true;
    }
    

    @FXML
    private void btnBack(ActionEvent event) throws IOException 
    {
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Are you sure you want to go back?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) 
        {
            Parent parent = FXMLLoader.load(getClass().getResource("/View/Appointments_View.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
    }
    }

    @FXML
    private void btnSignOut(ActionEvent event) throws IOException 
    {
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Are you sure you want to Sign Out?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) 
        {
            Parent parent = FXMLLoader.load(getClass().getResource("/View/Login_View.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }

    @FXML
    private void btnExit(ActionEvent event) throws IOException 
    {
        
        Main_Controller.alertWindow(4);
    }
        
    
        /** Fills Contact cbo with Contacts List
        */
        private void fillCboTime() 
        {
        ObservableList<String> apptTime = FXCollections.observableArrayList();
        LocalTime sTime = LocalTime.of(7, 0);
        LocalTime eTime = LocalTime.of(23, 0);

        apptTime.add(sTime.toString());
        while (sTime.isBefore(eTime)) 
        {
            sTime = sTime.plusMinutes(15);
            apptTime.add(sTime.toString());
        }

        cboSTime.setItems(apptTime);
        cboETime.setItems(apptTime);
    }

    /** Fills Contact cbo with Contacts List
     */
    private void fillCboContact() 
    {
        ObservableList<String> cboContactLs = FXCollections.observableArrayList();

        try {
            ObservableList<Contact> contacts = ContactQuery.getContacts();
            if (contacts != null)
            {
                for (Contact contact: contacts) 
                {
                    if (!cboContactLs.contains(contact.getContactName())) 
                    {
                        cboContactLs.add(contact.getContactName());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        cboContact.setItems(cboContactLs);
    }

    /** Fills Customer ID cbo with Customer ID List
     */
    private void fillCboCustId() 
    {
        ObservableList<Integer> cboCustIdLs = FXCollections.observableArrayList();

        try {
            ObservableList<Customer> customers = CustQuery.getCustomers();
            if (customers != null) 
            {
                for (Customer customer: customers) 
                {
                    cboCustIdLs.add(customer.getCustomerId());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        cboCustId.setItems(cboCustIdLs);
    }
    
    

    /** Fills User ID cbo with User ID List
     */
    private void fillCboUserId() 
    {
        ObservableList<Integer> cboUserIdLs = FXCollections.observableArrayList();

        try {
            ObservableList<User> users = UserQuery.getUsers();
            if (users != null) 
            {
                for (User user: users) 
                {
                    cboUserIdLs.add(user.getUserId());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        cboUserId.setItems(cboUserIdLs);
    }

    /** Fills Type cbo with Type List
     */
    private void fillCboType() 
    {
        ObservableList<String> cboTypeLs = FXCollections.observableArrayList();

        cboTypeLs.addAll("Planning Session", "De-Briefing", "Intake", "Pre-Briefing", "Open Session");

        cboType.setItems(cboTypeLs);
    }
    
    /** Fills Appt Id cbo with Appt Id List
     */
    private void fillCboApptId() 
    {
        
        ObservableList<Integer> apptIdList = FXCollections.observableArrayList();

        try {
            ObservableList<Appointment> appointments = ApptQuery.getAppts();
            if (appointments != null) 
            {
                for (Appointment appointment: appointments) 
                {
                    apptIdList.add(selAppt.getApptId());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


        cboApptId.setItems(apptIdList);
    }
    
    
    /**
     * Initializes controller
     * @param url url
     * @param rb resource bunble
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        
        fillCboTime();
        fillCboContact();
        fillCboCustId();
        fillCboUserId();
        fillCboType();
        fillCboApptId();

        try {
            Appointment appt = ApptQuery.getApptByApptID(selAppt.getApptId());

            ZonedDateTime zSTime = conToTimeZone(appt.getSDate().atTime(appt.getSTime().toLocalTime()), String.valueOf(ZoneId.of(TimeZone.getDefault().getID())));
            ZonedDateTime zETime = conToTimeZone(appt.getEDate().atTime(appt.getETime().toLocalTime()), String.valueOf(ZoneId.of(TimeZone.getDefault().getID())));

            if (appt != null) 
            {
                cboContact.getSelectionModel().select(String.valueOf(appt.getContactId()));
                txtTitle.setText(appt.getTitle());
                txtDescrip.setText(appt.getDescription());
                txtLoc.setText(appt.getLocation());
                cboType.getSelectionModel().select(appt.getType());
                cboUserId.getSelectionModel().select(Integer.valueOf(appt.getUserId()));
                dpSDate.setValue(appt.getSDate());
                cboSTime.getSelectionModel().select(String.valueOf(zSTime.toLocalTime()));
                dpEDate.setValue(appt.getEDate());
                cboETime.getSelectionModel().select(String.valueOf(zETime.toLocalTime()));
                cboCustId.getSelectionModel().select(Integer.valueOf(appt.getCustomerId()));
                cboApptId.getSelectionModel().select(Integer.valueOf(appt.getApptId()));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    }    
    

