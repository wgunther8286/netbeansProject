/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controller;

import Model.Country;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 * FXML Controller class
 *
 * @author r3j20
 */
public class Country_Controller implements Initializable {

    @FXML
    private TableView<Country> countryView;
    @FXML
    private TableColumn<Country, String> countryNameCol;
    @FXML
    private TableColumn<Country, Integer> countryIdCol;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void showCountires(ActionEvent event) throws SQLException {
        
        ObservableList<Country> countryList = DBQuery.CountriesQuery.getCountries();
        for(Country C : countryList) {
            System.out.println("Country Id: " + C.getId() + " Country Name: " + C.getName());
        }
    }
    
}
