/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controller;

import DBQuery.CountriesQuery;
import DBQuery.CustQuery;
import DBQuery.DivQuery;
import Model.Country;
import Model.Customer;
import Model.Division;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author r3j20
 */
public class Update_Customer_Controller implements Initializable 
{

    @FXML
    private Label lblCustId;
    
    @FXML
    private Label lblUserId;
    
    @FXML
    private Label lblTitle;
    @FXML
    private TextField txtName;
    @FXML
    private Label lblDescrip;
    @FXML
    private TextField txtAddress;
    @FXML
    private Label lblLoc;
    @FXML
    private TextField txtPostalCode;
    @FXML
    private Label lblLoc1;
    @FXML
    private TextField txtPhone;
    
    @FXML
    private ComboBox<String> cboCountry;

    @FXML
    private ComboBox<String> cboDivId;
    
    @FXML
    private ComboBox<Integer> cboCustId;

    private static Customer selCust;
    
    /**
     * Receives the selected customer from the customer view 
     * @param cust customer object
     */
    public static void rxSelCust(Customer cust) 
    {
        selCust = cust;
    }
    
    @FXML
    private void btnSave(ActionEvent event) throws IOException 
    {
        
        boolean filled = checkCust(
                txtName.getText(),
                txtAddress.getText(),
                txtPostalCode.getText(),
                txtPhone.getText());

        if (filled) 
        {
            try {
                boolean isFilled = CustQuery.updateCustomer(
                        cboCustId.getSelectionModel().getSelectedItem(),
                        txtName.getText(),
                        txtAddress.getText(),
                        txtPostalCode.getText(),
                        txtPhone.getText(),
                        cboDivId.getSelectionModel().getSelectedItem());
                        

                if (isFilled) 
                {
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Successfully updated customer");
                    Optional<ButtonType> result = alert.showAndWait();

                    if (result.isPresent() && (result.get() ==  ButtonType.OK)) 
                    {
                        try {
                            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                            Parent scene = FXMLLoader.load(getClass().getResource("/View/Customer_View.fxml"));
                            stage.setScene(new Scene(scene));
                            stage.show();
                        } catch (Exception e) {
                            e.printStackTrace();
                            Main_Controller.alertWindow(14);
                        }
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to save new customer");
                    Optional<ButtonType> result = alert.showAndWait();

                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    /** Checks Customer Fields are selected and not empty
     * Throws alert if fields are not selected or are empty
     * @param name String value of Customer Name
     * @param addr String value of Customer Address
     * @param postCode String value of Customer Postal Code
     * @param phone String value of Customer Phone Number
     * @return Boolean Returns true if filled and false if not filled
     */
    private boolean checkCust(String name, String addr, String postCode, String phone) throws IOException
    {
        if (name.isEmpty())
        {
            Main_Controller.alertWindow(5);
            return false;
        }

        if (addr.isEmpty())
        {
            Main_Controller.alertWindow(6);
            return false;
        }

        if (postCode.isEmpty())
        {
            Main_Controller.alertWindow(7);
            return false;
        }

        if (phone.isEmpty())
        {
            Main_Controller.alertWindow(10);
            return false;
        }

        if (cboDivId.getSelectionModel().isEmpty()) 
        {
            Main_Controller.alertWindow(11);
            return false;
        }

        if (cboCountry.getSelectionModel().isEmpty()) 
        {
            Main_Controller.alertWindow(13);
            return false;
        }

        return true;
    }

    @FXML
    private void btnBack(ActionEvent event) throws IOException 
    {
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Are you sure you want to go back?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) 
        {
            Parent parent = FXMLLoader.load(getClass().getResource("/View/Customer_View.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();

    }
    }

    @FXML
    private void btnSignOut(ActionEvent event) throws IOException 
    {
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Are you sure you want to Sign Out?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) 
        {
            Parent parent = FXMLLoader.load(getClass().getResource("/View/Login_View.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }

    @FXML
    private void btnExit(ActionEvent event) throws IOException 
    {
        
        Main_Controller.alertWindow(4);

    }
    /**
     * Fills Division cbo with Division List
     */
    private void fillCboDiv()
    {
        ObservableList<String> divisionList = FXCollections.observableArrayList();

        try {
            ObservableList<Division> divisions = DivQuery.getDivs();
            if (divisions != null) 
            {
                for (Division division: divisions) 
                {
                    divisionList.add(division.getDivision());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        cboDivId.setItems(divisionList);
    }

    /** Fills Country cbo with Country List
     */
    private void fillCboCountry()
    {
        ObservableList<String> countryList = FXCollections.observableArrayList();

        try {
            ObservableList<Country> countries = CountriesQuery.getCountries();
            if (countries != null) 
            {
                for (Country country: countries) 
                {
                    countryList.add(country.getName());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        cboCountry.setItems(countryList);
    }
    
    /**
     * Fills Customer ID cbo with Customer ID List
     */
    private void fillCboCustId() 
    {
        
        ObservableList<Integer> custIdList = FXCollections.observableArrayList();

        try {
            ObservableList<Customer> customers = CustQuery.getCustomers();
            if (customers != null) 
            {
                for (Customer customer: customers) 
                {
                    custIdList.add(selCust.getCustomerId());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        
        fillCboDiv();
        fillCboCountry();

        txtName.setText(selCust.getCustomerName());
        txtPostalCode.setText(selCust.getPostalCode());
        txtAddress.setText(selCust.getAddress());
        txtPhone.setText(selCust.getPhoneNumber());
        cboCountry.getSelectionModel().select(selCust.getCountry());
        cboDivId.getSelectionModel().select(selCust.getDivision());
        cboCustId.getSelectionModel().select(Integer.valueOf(selCust.getCustomerId()));
        
    }
        
        
    }    
    

