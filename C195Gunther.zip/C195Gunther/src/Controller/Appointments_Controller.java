/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controller;

import DBQuery.ApptQuery;
import Model.Appointment;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/** 
 * FXML Controller Class.
 * Controller for the Appointments_View.fxml.
 * 
 */
public class Appointments_Controller implements Initializable 
{
    
    @FXML
    private TableView<Appointment> tblAppts;
    
    @FXML
    private TableColumn<Appointment, Integer> colApptId;

    @FXML
    private TableColumn<Appointment, Integer> colCont;

    @FXML
    private TableColumn<Appointment, Integer> colCustId;

    @FXML
    private TableColumn<Appointment, String> colDescrip;

    @FXML
    private TableColumn<Appointment, LocalDateTime> colEnd;

    @FXML
    private TableColumn<Appointment, String> colLoc;

    @FXML
    private TableColumn<Appointment, LocalDateTime> colStart;

    @FXML
    private TableColumn<Appointment, String> colTitle;

    @FXML
    private TableColumn<Appointment, String> colType;

    @FXML
    private TableColumn<Appointment, Integer> colUserId;

    @FXML
    private RadioButton radBtnApptMonth;
    @FXML
    private RadioButton radBtnApptWeek;
    
    @FXML
    private ToggleGroup radioBtnToggle;
    
    static ObservableList<Appointment> appts;
    
    /**
     * Button for the Customers page.
     * @param event when clicked, moves user to the customers page.
     * @throws IOException 
     */
    @FXML
    void btnCustomers(ActionEvent event) throws IOException 
    {
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Are you sure you want to go to the Customers form?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) 
        {
            Parent parent = FXMLLoader.load(getClass().getResource("/View/Customer_View.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();

    }
    }
    /**
     * Button to delete the selected appointment.
     * @param event when clicked, deletes the appointment selected by the user.
     */
    @FXML
    void btnDeleteAppt(ActionEvent event) 
    {
        
        Appointment selAppt = tblAppts.getSelectionModel().getSelectedItem();
        if (selAppt == null) 
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("Select an appointment to delete.");
            alert.showAndWait();
        } else if (tblAppts.getSelectionModel().getSelectedItem() != null) 
        {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to delete Appointment: ApptID:  " + selAppt.getApptId() + " ? "
                    + "\nPress ok to Delete?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && (result.get() == ButtonType.OK)) {
                try {
                    boolean delSuccessful = ApptQuery.deleteAppt(tblAppts.getSelectionModel().getSelectedItem().getApptId());

                    if (delSuccessful) {
                        alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Successful Delete");
                        alert.setContentText("Deleted Appointment ID: " + selAppt.getApptId() + " Type: " + selAppt.getType());
                        alert.showAndWait();

                        appts = ApptQuery.getAppts();
                        tblAppts.setItems(appts);
                        tblAppts.refresh();
                    } else {
                        alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error Dialog");
                        alert.setContentText("Could not delete appointment.");
                        alert.showAndWait();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }


    }

    /**
     * Button for the Update screen.
     * @param event When clicked, moves user to the update appointment view with the selected appointment data.
     */
    @FXML
    void btnUpdate(ActionEvent event) 
    {
        
        Update_Appointment_Controller.rxSelAppt(tblAppts.getSelectionModel().getSelectedItem());

        if (tblAppts.getSelectionModel().getSelectedItem() != null) {
            try {
                Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
                Parent scene = FXMLLoader.load(getClass().getResource("/View/Update_Appointment_View.fxml"));
                stage.setScene(new Scene(scene));
                stage.setTitle("Update Existing Appointment");
                stage.show();
            } catch (Exception e) {
                e.printStackTrace();
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error Dialog");
                alert.setContentText("Load Screen Error.");
                alert.showAndWait();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("You must select an appointment to update.");
            alert.showAndWait();
        }

    }
    /**
     * Button to exit the application
     * @param event When clicked, Displays confirmation screen to ensure user wants to exit the application.
     * @throws IOException 
     */
    @FXML
    void btnExit(ActionEvent event) throws IOException 
    {
        
        Main_Controller.alertWindow(4);
    }
    /**
     * Button for the create appointment screen.
     * @param event When clicked, moves the user to the create appointment view.
     * @throws IOException 
     */
    @FXML
    void btnNewAppt(ActionEvent event) throws IOException 
    {
        
        Parent parent = FXMLLoader.load(getClass().getResource("/View/Create_Appointment_View.fxml"));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void btnBack(ActionEvent event) throws IOException 
    {
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Alert");
        alert.setContentText("Are you sure you want to return to main form?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) 
        {
            Parent parent = FXMLLoader.load(getClass().getResource("/View/Main_View.fxml"));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();

        }
    }
     
    @FXML
    void ViewToggle(ActionEvent event) 
    {
        
        if (radBtnApptMonth.isSelected()) 
        {
            try {
                appts = ApptQuery.getApptsMth();
                tblAppts.setItems(appts);
                tblAppts.refresh();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else if (radBtnApptWeek.isSelected()) {
            try {
                appts = ApptQuery.getApptsWk();
                tblAppts.setItems(appts);
                tblAppts.refresh();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            
        } 
        else if (radBtnApptWeek.isSelected() == false && (radBtnApptMonth.isSelected() == false))   {
            try {
                appts = ApptQuery.getAppts();
                tblAppts.setItems(appts);
                tblAppts.refresh();
            } catch (SQLException e) {
                e.printStackTrace();
        }
        
        }   
    }
    /**
     * Initializes controller class
     * @param url url
     * @param rb resource bundle
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        radBtnApptMonth.setToggleGroup(radioBtnToggle);
        radBtnApptWeek.setToggleGroup(radioBtnToggle);
        
        try {
            appts = ApptQuery.getAppts();

            tblAppts.setItems(appts);
            colApptId.setCellValueFactory(new PropertyValueFactory<>("apptId"));
            colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
            colDescrip.setCellValueFactory(new PropertyValueFactory<>("description"));
            colLoc.setCellValueFactory(new PropertyValueFactory<>("location"));
            colCont.setCellValueFactory(new PropertyValueFactory<>("contactId"));
            colType.setCellValueFactory(new PropertyValueFactory<>("type"));
            colStart.setCellValueFactory(new PropertyValueFactory<>("sTime"));
            colEnd.setCellValueFactory(new PropertyValueFactory<>("eTime"));
            colCustId.setCellValueFactory(new PropertyValueFactory<>("customerId"));
            colUserId.setCellValueFactory(new PropertyValueFactory<>("userId"));

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    }


    
    

